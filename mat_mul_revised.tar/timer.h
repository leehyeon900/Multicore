#pragma once

void timer_start(int i);
double timer_stop(int i);
